// server/models/Photo.js
const mongoose = require('mongoose');

const PhotoSchema = new mongoose.Schema({
  // 1. 文件关联核心
  albumIds: [{ type: String }],                      // 所属作品集（可多归属：地点自动 + 用户手动）
  originalName: { type: String },                    // 原始文件名，兼容旧数据
  fileName: { type: String },                        // 前端传来的文件名，如 photo.webp
  imageUrl: { type: String, required: true },        // 图片公网访问路径
  status: { type: String, enum: ['raw', 'master'], default: 'raw' },
  isDraft: { type: Boolean, default: false },        // 草稿标记，前台瀑布流不显示

  // 多版本对比的核心纽带
  parentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Photo', default: null },
  versionName: { type: String, default: '原图' },

  // 展示版：指向用作瀑布流/作品集展示的版本
  displayVersionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Photo', default: null },
  displayImageUrl: { type: String, default: '' },

  // 2. EXIF 子文档（前端 canvas 解析后传入）
  exif: {
    camera: { type: String, default: 'Unknown Camera' },
    lens: { type: String, default: 'Unknown Lens' },
    aperture: { type: String, default: 'f/0.0' },      // 如 f/2.8
    iso: { type: String, default: '0' },
    shutterSpeed: { type: String, default: '0s' },      // 如 1/500s
    focalLength: { type: String, default: '0mm' },      // 如 32.5mm
    dateTimeOriginal: { type: Date }
  },

  // 3. 地图足迹
  region: { type: String, default: '' },
  locationName: { type: String, default: '未标记地点' },
  coordinates: {
    lat: { type: Number },
    lng: { type: Number }
  },

  // 4. 色彩分析（前端提取后传入，避免每次刷新重新计算）
  colors: [{
    hex: { type: String },
    name: { type: String }
  }],

  // 5. 内容叙事层
  title: { type: String, default: '' },
  caption: { type: String, default: '' },

  // 6. AI 构图分析
  analysis: {
    radar: [{
      label: { type: String },
      value: { type: Number }
    }],
    result: { type: String, default: '' },
    analyzedAt: { type: Date }
  },

  createdAt: { type: Date, default: Date.now }
});

// 导出这个模型，让 photoRoutes.js 路由里可以通过 Photo.create() 去写入它
module.exports = mongoose.model('Photo', PhotoSchema);